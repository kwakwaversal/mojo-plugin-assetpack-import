React.renderComponent(
var app = function(){};
  <h1>Hello, world!</h1>,
  document.getElementById('example')
);
