// some very long comment which should mark this file as already minified, but since it is a comment and the javascript is code is not minified it still gets minified... need to add some more text here to make sure it gets longer than MINIFIED_LINE_LENGTH, which by default is set to 300. 310 chars is enough.
(function(w) {
  w.console.log('a');
}(window));
