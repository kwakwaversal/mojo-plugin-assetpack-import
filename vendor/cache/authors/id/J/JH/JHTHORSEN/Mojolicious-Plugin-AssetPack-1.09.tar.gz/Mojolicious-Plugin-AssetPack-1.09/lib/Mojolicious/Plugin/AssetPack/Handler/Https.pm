package Mojolicious::Plugin::AssetPack::Handler::Https;
use Mojo::Base 'Mojolicious::Plugin::AssetPack::Handler::Http';

1;

=encoding utf8

=head1 NAME

Mojolicious::Plugin::AssetPack::Handler::Https - DEPRECATED

=head1 DESCRIPTION

See L<Mojolicious::Plugin::AssetPack::Handler::Http>.

=head1 SEE ALSO

L<Mojolicious::Plugin::AssetPack>.

=cut
